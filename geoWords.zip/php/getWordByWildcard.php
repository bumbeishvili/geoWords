<?php
 $arr = array(array ('value'=>'ვაიfesfsლდქარდი'));
 array_push($arr, array ('value'=>'ვაიfesdwafsლდქარდი'));
 array_push($arr, array ('value'=>'ვაიfeswdaawdfsლდქარდი'));
 array_push($arr, array ('value'=>'ვაიdawdawfesfsლდქარდი'));
 echo (json_encode($arr));

?>