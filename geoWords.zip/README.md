# geoWords
 <code>DML</code> მანიპულაციები ქართული სიტყვების ბაზაზე

<b> Status : </b> <code>In development</code>
<br><br>
<a href="http://geowords.byethost12.com/ " target='_blank'> Working demo </a>
